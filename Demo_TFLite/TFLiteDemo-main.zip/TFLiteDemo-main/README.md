# TFLiteDemo
 Simple TFLite Demo with MNIST Digits Classification
